-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mar 30 Juin 2020 à 10:56
-- Version du serveur: 5.1.53
-- Version de PHP: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `gestion_notes_scolaires`
--

-- --------------------------------------------------------

--
-- Structure de la table `t_branche`
--

CREATE TABLE IF NOT EXISTS `t_branche` (
  `branche_id` int(11) NOT NULL AUTO_INCREMENT,
  `intitule` varchar(59) CHARACTER SET utf8 NOT NULL,
  `enseignant_id` int(11) NOT NULL,
  `classe_id` int(11) NOT NULL,
  PRIMARY KEY (`branche_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Contenu de la table `t_branche`
--

INSERT INTO `t_branche` (`branche_id`, `intitule`, `enseignant_id`, `classe_id`) VALUES
(1, 'Religion', 1, 2),
(2, 'Ed. cv & morale', 1, 2),
(3, 'Education a la vie', 1, 2),
(4, 'Informatique', 1, 2),
(5, 'Education physique', 1, 2),
(6, 'Dessin', 1, 2),
(7, 'Histoire', 1, 2),
(8, 'Geographie', 1, 2),
(9, 'Esthetique', 1, 2),
(10, 'Anglais', 1, 2),
(11, 'Biologie', 1, 2),
(12, 'Chimie', 1, 2),
(13, 'Physique', 1, 2),
(14, 'Francais', 1, 2),
(15, 'Mathematiques', 2, 2),
(16, 'Religion', 11, 3),
(17, 'Ed. cv & morale', 10, 3),
(19, 'Informatique', 12, 3),
(20, 'Biologie', 9, 3),
(22, 'Dessin', 6, 3),
(23, 'Education physique', 13, 3),
(24, 'Geographie', 7, 3),
(25, 'Histoire', 7, 3),
(26, 'Esthetique', 8, 3),
(27, 'Anglais', 14, 3),
(28, 'Physique', 5, 3),
(29, 'Francais', 4, 3),
(30, 'Mathematiques', 3, 3),
(31, 'Religion', 11, 4),
(32, 'Ed. cv & morale', 10, 4),
(33, 'Informatique', 12, 4),
(34, 'Biologie', 9, 4),
(35, 'Dessin', 6, 4),
(36, 'Education physique', 13, 4),
(37, 'Geographie', 7, 4),
(38, 'Histoire', 7, 4),
(39, 'Philosophie', 15, 4),
(40, 'Anglais', 14, 4),
(41, 'Physique', 5, 4),
(42, 'Francais', 4, 4),
(43, 'Mathematiques', 3, 4);

-- --------------------------------------------------------

--
-- Structure de la table `t_classe`
--

CREATE TABLE IF NOT EXISTS `t_classe` (
  `classe_id` int(11) NOT NULL AUTO_INCREMENT,
  `intitule` varchar(10) NOT NULL,
  `cycle_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  PRIMARY KEY (`classe_id`),
  KEY `cycle_id` (`cycle_id`),
  KEY `option_id` (`option_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `t_classe`
--

INSERT INTO `t_classe` (`classe_id`, `intitule`, `cycle_id`, `option_id`) VALUES
(1, '3', 3, 1),
(2, '5', 3, 1),
(3, '5', 3, 2),
(4, '6', 3, 2);

-- --------------------------------------------------------

--
-- Structure de la table `t_concerner`
--

CREATE TABLE IF NOT EXISTS `t_concerner` (
  `maxima_id` int(11) NOT NULL,
  `branche_id` int(11) NOT NULL,
  `periode_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `t_concerner`
--

INSERT INTO `t_concerner` (`maxima_id`, `branche_id`, `periode_id`) VALUES
(1, 1, 1),
(1, 2, 1),
(1, 3, 1),
(1, 4, 1),
(2, 5, 1),
(2, 6, 1),
(2, 7, 1),
(2, 8, 1),
(2, 9, 1),
(3, 10, 1),
(3, 11, 1),
(3, 12, 1),
(3, 13, 1),
(4, 14, 1),
(4, 15, 1),
(1, 1, 2),
(1, 2, 2),
(1, 3, 2),
(1, 4, 2),
(2, 5, 2),
(2, 6, 2),
(2, 7, 2),
(2, 8, 2),
(2, 9, 2),
(3, 10, 2),
(3, 11, 2),
(3, 12, 2),
(3, 13, 2),
(4, 14, 2),
(4, 15, 2),
(1, 1, 3),
(1, 2, 3),
(1, 3, 3),
(1, 4, 3),
(2, 5, 3),
(2, 6, 3),
(2, 7, 3),
(2, 8, 3),
(2, 9, 3),
(3, 10, 3),
(3, 11, 3),
(3, 12, 3),
(3, 13, 3),
(4, 14, 3),
(4, 15, 3),
(1, 1, 4),
(1, 2, 4),
(1, 3, 4),
(1, 4, 4),
(2, 5, 4),
(2, 6, 4),
(2, 7, 4),
(2, 8, 4),
(2, 9, 4),
(3, 10, 4),
(3, 11, 4),
(3, 12, 4),
(3, 13, 4),
(4, 14, 4),
(4, 15, 4),
(2, 1, 5),
(2, 2, 5),
(2, 3, 5),
(2, 4, 5),
(3, 5, 5),
(3, 6, 5),
(3, 7, 5),
(3, 8, 5),
(3, 9, 5),
(5, 10, 5),
(5, 11, 5),
(5, 12, 5),
(5, 13, 5),
(6, 14, 5),
(6, 15, 5),
(2, 1, 6),
(2, 2, 6),
(2, 3, 6),
(2, 4, 6),
(3, 5, 6),
(3, 6, 6),
(3, 7, 6),
(3, 8, 6),
(3, 9, 6),
(5, 10, 6),
(5, 11, 6),
(5, 12, 6),
(5, 13, 6),
(6, 14, 6),
(6, 15, 6),
(3, 1, 7),
(3, 2, 7),
(3, 3, 7),
(3, 4, 7),
(5, 5, 7),
(5, 6, 7),
(5, 7, 7),
(5, 8, 7),
(5, 9, 7),
(7, 10, 7),
(7, 11, 7),
(7, 12, 7),
(7, 13, 7),
(8, 14, 7),
(8, 15, 7),
(3, 2, 8),
(3, 3, 8),
(3, 4, 8),
(3, 1, 8),
(5, 5, 8),
(5, 6, 8),
(5, 7, 8),
(5, 8, 8),
(5, 9, 8),
(7, 10, 8),
(7, 11, 8),
(7, 12, 8),
(7, 13, 8),
(8, 14, 8),
(8, 15, 8),
(5, 1, 9),
(5, 2, 9),
(5, 3, 9),
(5, 4, 9),
(7, 5, 9),
(7, 6, 9),
(7, 7, 9),
(7, 8, 9),
(7, 9, 9),
(9, 10, 9),
(9, 11, 9),
(9, 12, 9),
(9, 13, 9),
(10, 14, 9),
(10, 15, 9),
(1, 16, 1),
(1, 17, 1),
(1, 18, 1),
(1, 19, 1),
(2, 20, 1),
(2, 21, 1),
(2, 22, 1),
(2, 23, 1),
(2, 24, 1),
(2, 25, 1),
(2, 26, 1),
(3, 27, 1),
(3, 28, 1),
(4, 29, 1),
(4, 30, 1),
(1, 16, 2),
(1, 17, 2),
(1, 18, 2),
(1, 19, 2),
(2, 20, 2),
(2, 21, 2),
(2, 22, 2),
(2, 23, 2),
(2, 24, 2),
(2, 25, 2),
(2, 26, 2),
(3, 27, 2),
(3, 28, 2),
(4, 29, 2),
(4, 30, 2),
(1, 16, 3),
(1, 17, 3),
(1, 18, 3),
(1, 19, 3),
(2, 20, 3),
(2, 21, 3),
(2, 22, 3),
(2, 23, 3),
(2, 24, 3),
(2, 25, 3),
(2, 26, 3),
(3, 27, 3),
(3, 28, 3),
(4, 29, 3),
(4, 30, 3),
(1, 16, 4),
(1, 17, 4),
(1, 18, 4),
(1, 19, 4),
(2, 20, 4),
(2, 21, 4),
(2, 22, 4),
(2, 23, 4),
(2, 24, 4),
(2, 25, 4),
(2, 26, 4),
(3, 27, 4),
(3, 28, 4),
(4, 29, 4),
(4, 30, 4),
(2, 16, 5),
(2, 17, 5),
(2, 18, 5),
(2, 19, 5),
(3, 20, 5),
(3, 21, 5),
(3, 22, 5),
(3, 23, 5),
(3, 24, 5),
(3, 25, 5),
(3, 26, 5),
(5, 27, 5),
(5, 28, 5),
(6, 29, 5),
(6, 30, 5),
(2, 16, 6),
(2, 17, 6),
(2, 18, 6),
(2, 19, 6),
(3, 20, 6),
(3, 21, 6),
(3, 22, 6),
(3, 23, 6),
(3, 24, 6),
(3, 25, 6),
(3, 26, 6),
(5, 27, 6),
(5, 28, 6),
(6, 29, 6),
(6, 30, 6),
(3, 16, 7),
(3, 17, 7),
(3, 18, 7),
(3, 19, 7),
(5, 20, 7),
(5, 21, 7),
(5, 22, 7),
(5, 23, 7),
(5, 24, 7),
(5, 25, 7),
(5, 26, 7),
(7, 27, 7),
(7, 28, 7),
(8, 29, 7),
(8, 30, 7),
(3, 16, 8),
(3, 17, 8),
(3, 18, 8),
(3, 19, 8),
(5, 20, 8),
(5, 21, 8),
(5, 22, 8),
(5, 23, 8),
(5, 24, 8),
(5, 25, 8),
(5, 26, 8),
(7, 27, 8),
(7, 28, 8),
(8, 29, 8),
(8, 30, 8),
(5, 16, 9),
(5, 17, 9),
(5, 18, 9),
(5, 19, 9),
(7, 20, 9),
(7, 21, 9),
(7, 22, 9),
(7, 23, 9),
(7, 24, 9),
(7, 25, 9),
(7, 26, 9),
(9, 27, 9),
(9, 28, 9),
(10, 29, 9),
(10, 30, 9),
(1, 31, 1),
(1, 32, 1),
(1, 33, 1),
(2, 34, 1),
(2, 35, 1),
(2, 36, 1),
(2, 37, 1),
(2, 38, 1),
(2, 39, 1),
(3, 40, 1),
(3, 41, 1),
(4, 42, 1),
(4, 43, 1),
(1, 31, 2),
(1, 32, 2),
(1, 33, 2),
(2, 34, 2),
(2, 35, 2),
(2, 36, 2),
(2, 37, 2),
(2, 38, 2),
(3, 39, 2),
(3, 40, 2),
(3, 41, 2),
(4, 42, 2),
(4, 43, 2),
(1, 31, 3),
(1, 32, 3),
(1, 33, 3),
(2, 34, 3),
(2, 35, 3),
(2, 36, 3),
(2, 37, 3),
(2, 38, 3),
(3, 39, 3),
(3, 40, 3),
(3, 41, 3),
(4, 42, 3),
(4, 43, 3),
(1, 31, 4),
(1, 32, 4),
(1, 33, 4),
(2, 35, 4),
(2, 36, 4),
(2, 37, 4),
(2, 38, 4),
(2, 39, 4),
(3, 40, 4),
(3, 41, 4),
(4, 42, 4),
(4, 43, 4),
(2, 31, 5),
(2, 32, 5),
(2, 33, 5),
(3, 34, 5),
(3, 35, 5),
(3, 36, 5),
(3, 37, 5),
(3, 39, 5),
(5, 40, 5),
(5, 41, 5),
(6, 42, 5),
(6, 43, 5),
(2, 31, 6),
(2, 32, 6),
(2, 33, 6),
(3, 34, 6),
(3, 35, 6),
(3, 36, 6),
(3, 37, 6),
(3, 38, 6),
(3, 39, 6),
(5, 40, 6),
(5, 41, 6),
(6, 42, 6),
(6, 43, 6),
(3, 31, 7),
(3, 32, 7),
(3, 33, 7),
(5, 34, 7),
(5, 35, 7),
(5, 36, 7),
(5, 37, 7),
(5, 38, 7),
(5, 39, 7),
(7, 40, 7),
(7, 41, 7),
(8, 42, 7),
(8, 43, 7),
(3, 31, 8),
(3, 32, 8),
(3, 33, 8),
(5, 34, 8),
(5, 35, 8),
(5, 36, 8),
(5, 37, 8),
(5, 38, 8),
(5, 39, 8),
(7, 40, 8),
(7, 41, 8),
(8, 42, 8),
(8, 43, 8),
(5, 31, 9),
(5, 32, 9),
(5, 33, 9),
(7, 34, 9),
(7, 35, 9),
(7, 36, 9),
(7, 37, 9),
(7, 38, 9),
(7, 39, 9),
(9, 40, 9),
(9, 41, 9),
(10, 42, 9),
(10, 43, 9);

-- --------------------------------------------------------

--
-- Structure de la table `t_cycle`
--

CREATE TABLE IF NOT EXISTS `t_cycle` (
  `cycle_id` int(11) NOT NULL AUTO_INCREMENT,
  `intitule` varchar(50) NOT NULL,
  PRIMARY KEY (`cycle_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `t_cycle`
--

INSERT INTO `t_cycle` (`cycle_id`, `intitule`) VALUES
(1, 'Maternelle'),
(2, 'Primaire'),
(3, 'Secondaire');

-- --------------------------------------------------------

--
-- Structure de la table `t_eleve`
--

CREATE TABLE IF NOT EXISTS `t_eleve` (
  `eleve_id` int(11) NOT NULL AUTO_INCREMENT,
  `matricule` varchar(20) DEFAULT NULL,
  `nom` varchar(26) DEFAULT NULL,
  `postnom` varchar(26) DEFAULT NULL,
  `prenom` varchar(26) DEFAULT NULL,
  `nom_tuteur` varchar(26) DEFAULT NULL,
  `sexe` varchar(1) DEFAULT NULL,
  `lieu_naissance` varchar(26) DEFAULT NULL,
  `date_naissance` varchar(50) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `adresse` text,
  `classe_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`eleve_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Contenu de la table `t_eleve`
--

INSERT INTO `t_eleve` (`eleve_id`, `matricule`, `nom`, `postnom`, `prenom`, `nom_tuteur`, `sexe`, `lieu_naissance`, `date_naissance`, `telephone`, `adresse`, `classe_id`) VALUES
(1, '3130793', 'TSHIBANGU', 'MAYOMBO', 'Elie', 'MAYOMBO', 'M', 'Kinshasa', '1993-07-07', '0822013462', 'Lemba', 2),
(2, '3251392', 'TSHINGAMBU', 'BAMUSHINDA', 'Jacques', 'BAMUSHINDA', 'M', 'Kinshasa', '1992-01-13', '08995222267', 'campa', 2),
(3, '3251293', 'MASSAMBA', 'DIAKANUA', 'Henock', 'DIAKANUA', 'M', 'Kinshasa', '1993-01-12', '0822013462', 'Ngaliema', 2),
(4, '3352803', 'TSHIANI', 'MUKENDI', 'Believe', 'MUKENDI', 'M', 'Kinshasa', '2003-05-28', '0899522267', 'av. mongando', 3),
(5, '3130793', 'BAKU', 'KINKELA', 'KINKELA', 'BAKU', 'F', 'Kinshasa', '1993-07-07', '822013462', 'Mt Ngafula', 3),
(6, '3251392', 'BOFAYA', 'NGILIMA', 'BOFAYA ', 'BOFAYA', 'M', 'Kinshasa', '1992-01-13', '8995222267', 'Mt Ngafula', 3),
(7, '3251293', 'DITINA', 'MPUNA', 'DITINA ', 'DITINA ', 'F', 'Kinshasa	', '1993-01-12', '822013463	', 'Mt Ngafula', 3),
(8, '	  ', 'KIAMVU', 'BAKEBIDIO ', 'KIAMVU', '', 'M', 'Kinshasa', '		    ', '        ', 'Mt Ngafula', 3),
(9, '', 'LUHANGA', 'MUBAKE', 'Jockana', 'LUHANGU', 'M', 'Kinshasa', '', ' ', 'Mt Ngafula', 3),
(10, '	   ', 'MANGALA', 'KINABOBEMBO', 'MANGALA', 'MANGALA ', 'M', 'Kinshasa', '		    ', '        ', 'Mt Ngafula', 3),
(11, ' ', 'MPUKI', 'TSINGU ', 'MPUKI', 'MPUKI', 'M', 'Kinshasa', '', '', 'Mt Ngafula', 3),
(12, ' ', 'MUFIDI', 'MANGAFU', 'MUFIDI', 'MUFIDI', 'M', 'Kinshasa', ' ', ' ', 'Mt Ngafula', 3),
(13, '  ', 'NZUZI', 'NKUKILA', 'NKUKILA', 'NZUZI', 'F', 'Kinshasa', '		    ', '      ', 'Mt Ngafula', 3),
(14, '	', 'TSHIBANGU', 'MBAYA', 'TSHIBANGU', 'TSHIBANGU', 'M', 'Kinshasa', '		    ', '      ', 'Mt Ngafula', 3),
(15, ' ', 'TUZOLANA', 'KITAMBALA', 'TUZOLANA', 'TUZOLANA ', 'F', 'Kinshasa', '		    ', '       ', 'Mt Ngafula', 3),
(16, '', 'BUNDULA', 'NGUVULU', ' ', 'BUNDULA', 'M', 'Kinshasa', '	', '	', 'Mt Ngafula', 4),
(17, '', 'LUVILA', 'BASILE', '	', 'BASILE', 'M', 'Kinshasa', '	', '	', 'Mt Ngafula', 4),
(18, '', 'MAKOSI', 'KIMBEMBI', '		', 'MAKOSI', '	', 'Kinshasa', '	', '		', 'Mt Ngafula', 4),
(19, '', 'MAYAMBA', 'MAYITUKA', '		', 'MAYAMBA', 'F', 'Kinshasa', '	', '	', '	Mt Ngafula', 4),
(20, '', 'MBALA', 'MASAMBA', '		', 'MBALA', '	', 'Kinshasa', '	', '	', 'Mt Ngafula', 4),
(21, '', 'NTITA', 'MAKANDA', '		', 'NTITA', 'M', 'Kinshasa', '	', '	', 'Mt Ngafula', 4),
(22, '', 'TSHIANI', 'MUKENDI', '		', 'TSHIANI', 'M', 'Kinshasa', '	', '		', 'Mt Ngafula', 4),
(23, '', 'ZOLA', 'ROGER', '	', 'ZOLA', 'M', 'Kinshasa', '		', '  ', 'Mt Ngafula', 4);

-- --------------------------------------------------------

--
-- Structure de la table `t_enseignant`
--

CREATE TABLE IF NOT EXISTS `t_enseignant` (
  `enseignant_id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(20) NOT NULL,
  `nom` varchar(26) NOT NULL,
  `postnom` varchar(26) NOT NULL,
  `prenom` varchar(26) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  PRIMARY KEY (`enseignant_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Contenu de la table `t_enseignant`
--

INSERT INTO `t_enseignant` (`enseignant_id`, `login`, `nom`, `postnom`, `prenom`, `pwd`) VALUES
(1, 'Joice MM', 'MAYOMBO', 'MAYOMBO', 'Joice', 'joice'),
(2, 'Gilbert', 'NTUMBA', 'BADIBANGA', 'Gilbert', 'gilbert'),
(3, 'yves', 'MALONGA', 'KITADI', 'Yves', 'yves'),
(4, 'anatole', 'NGBEDANGO', 'MWANGO', 'Anatole', 'anatole'),
(5, 'moise', 'MATONDO', 'MATONDO', 'Moise', 'moise'),
(6, 'alain', 'MUKONKOLE', 'MUEYI', 'Alain', 'alain'),
(7, 'djonicko', 'KAZIAMA', 'MULAY', 'Djonicko', 'djonicko'),
(8, 'ernest', 'LUWONGO', 'MAKONDAMBUTA', 'Ernest', 'ernest'),
(9, 'ruben', 'NZUZI', 'NZAU', 'Ruben', 'ruben'),
(10, 'simon', 'BANDUKISA', 'BANDUKISA', 'Simon', 'simon'),
(11, 'kinkondo', 'KINKONDO', 'MBURAFUL', 'kinkondo', 'kinkondo'),
(12, 'ram', 'KIKWIKILA', 'SENDA', 'Ram', 'ram'),
(13, 'ngbanzo', 'NGBANZO', 'MAKOSA', 'ngbanzo', 'ngbanzo'),
(14, 'kati', 'KATI', 'KANDA', 'kati', 'kati'),
(15, 'luwondo', 'LUWONGO', 'LUWONGO', 'luwongo', 'luwongo'),
(16, 'gilbert', 'NTUMBA', 'KABEYA', 'Gilbert', 'gilbert');

-- --------------------------------------------------------

--
-- Structure de la table `t_envoyer`
--

CREATE TABLE IF NOT EXISTS `t_envoyer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `date_envoi` varchar(21) NOT NULL,
  `expediteur` varchar(50) NOT NULL,
  `destinateur` varchar(50) NOT NULL,
  `enseignant_id` int(11) NOT NULL,
  `periode_id` int(11) NOT NULL,
  `classe_id` int(11) NOT NULL,
  `branche_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `t_envoyer`
--

INSERT INTO `t_envoyer` (`id`, `message`, `date_envoi`, `expediteur`, `destinateur`, `enseignant_id`, `periode_id`, `classe_id`, `branche_id`) VALUES
(1, 'Bonjour Mr. le directeur, je m''excuse pour le retard mais j''envoie ce soir!', '19-02-2020  15:56:01', 'vous', 'direction', 1, 1, 2, 1),
(2, 'Veuillez envoyer les cotes de religion', '19-02-2020  17:11:11', 'direction', 'Joice Mayombo', 1, 1, 2, 1),
(3, 'Veuillez envoyer les cotes d''histoire', '26/02/20 16:40', 'direction', 'Joice MAYOMBO', 1, 2, 2, 7),
(4, 'd''accord, je l''enverrai ce soir sans doute', '26-02-2020  15:45:38', 'vous', 'direction', 1, 2, 2, 7),
(5, 'envoyer les cotes d''informatique', '02/03/20 15:12', 'direction', 'Joice MAYOMBO', 1, 2, 2, 4),
(6, 'D''accord j''enverrai demain', '02-03-2020  14:13:20', 'vous', 'direction', 1, 2, 2, 4);

-- --------------------------------------------------------

--
-- Structure de la table `t_maxima`
--

CREATE TABLE IF NOT EXISTS `t_maxima` (
  `maxima_id` int(11) NOT NULL AUTO_INCREMENT,
  `intitule` int(11) NOT NULL,
  PRIMARY KEY (`maxima_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `t_maxima`
--

INSERT INTO `t_maxima` (`maxima_id`, `intitule`) VALUES
(1, 10),
(2, 20),
(3, 40),
(4, 50),
(5, 80),
(6, 100),
(7, 160),
(8, 200),
(9, 320),
(10, 400);

-- --------------------------------------------------------

--
-- Structure de la table `t_nonaccepter`
--

CREATE TABLE IF NOT EXISTS `t_nonaccepter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branche_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `t_nonaccepter`
--

INSERT INTO `t_nonaccepter` (`id`, `branche_id`) VALUES
(1, 3),
(2, 18),
(3, 21);

-- --------------------------------------------------------

--
-- Structure de la table `t_note`
--

CREATE TABLE IF NOT EXISTS `t_note` (
  `note_id` int(11) NOT NULL AUTO_INCREMENT,
  `pointObtenu` int(11) NOT NULL,
  `branche_id` int(11) NOT NULL,
  `periode_id` int(11) NOT NULL,
  `eleve_id` int(11) NOT NULL,
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Contenu de la table `t_note`
--

INSERT INTO `t_note` (`note_id`, `pointObtenu`, `branche_id`, `periode_id`, `eleve_id`) VALUES
(1, 9, 1, 1, 1),
(2, 9, 1, 1, 2),
(3, 6, 1, 1, 3),
(4, 7, 2, 1, 3),
(5, 5, 4, 1, 3),
(6, 6, 16, 1, 4),
(7, 7, 17, 1, 4),
(8, 5, 19, 1, 4),
(9, 11, 20, 1, 4),
(10, 12, 22, 1, 4),
(11, 15, 23, 1, 4),
(12, 14, 24, 1, 4),
(13, 8, 25, 1, 4),
(14, 12, 26, 1, 4),
(15, 32, 27, 1, 4),
(16, 22, 28, 1, 4),
(17, 31, 29, 1, 4),
(18, 40, 30, 1, 4);

-- --------------------------------------------------------

--
-- Structure de la table `t_option`
--

CREATE TABLE IF NOT EXISTS `t_option` (
  `option_id` int(11) NOT NULL AUTO_INCREMENT,
  `intitule` varchar(50) CHARACTER SET utf8 NOT NULL,
  `section_id` int(11) NOT NULL,
  PRIMARY KEY (`option_id`),
  KEY `section_id` (`section_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `t_option`
--

INSERT INTO `t_option` (`option_id`, `intitule`, `section_id`) VALUES
(1, 'Biochimie', 1),
(2, 'Math-Physique', 1),
(3, 'Latin Philo', 3);

-- --------------------------------------------------------

--
-- Structure de la table `t_periode_total`
--

CREATE TABLE IF NOT EXISTS `t_periode_total` (
  `periode_id` int(11) NOT NULL AUTO_INCREMENT,
  `intitule` varchar(20) NOT NULL,
  `Sigle` varchar(5) CHARACTER SET utf8 NOT NULL,
  `semestre_id` int(11) NOT NULL,
  PRIMARY KEY (`periode_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `t_periode_total`
--

INSERT INTO `t_periode_total` (`periode_id`, `intitule`, `Sigle`, `semestre_id`) VALUES
(1, '1ere periode', '1ere ', 1),
(2, '2eme periode', '2e P', 1),
(3, '3eme periode', '3e P', 2),
(4, '4eme periode', '4e P', 2),
(5, 'Examen 1', 'Exam1', 1),
(6, 'Examen 2', 'Exam2', 2),
(7, 'Total 1', 'Tot1', 1),
(8, 'Total 2', 'Tot2', 2),
(9, 'Total Gen', 'T.G', 0);

-- --------------------------------------------------------

--
-- Structure de la table `t_resultat`
--

CREATE TABLE IF NOT EXISTS `t_resultat` (
  `eleve_id` int(11) NOT NULL,
  `periode_id` int(11) NOT NULL,
  `branche_id` int(11) NOT NULL,
  `classe_id` int(11) NOT NULL,
  `maxima_id` int(11) NOT NULL,
  `maxima` int(11) NOT NULL,
  `note_id` int(11) NOT NULL,
  `pointObtenu` int(11) NOT NULL,
  `pourcentage` varchar(11) NOT NULL,
  `totalObtenu` double NOT NULL,
  `TG` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `t_resultat`
--

INSERT INTO `t_resultat` (`eleve_id`, `periode_id`, `branche_id`, `classe_id`, `maxima_id`, `maxima`, `note_id`, `pointObtenu`, `pourcentage`, `totalObtenu`, `TG`) VALUES
(4, 1, 16, 3, 1, 10, 6, 6, '65.0', 215, 330),
(4, 1, 17, 3, 1, 10, 7, 7, '65.0', 215, 330),
(4, 1, 19, 3, 1, 10, 8, 5, '65.0', 215, 330),
(4, 1, 20, 3, 2, 20, 9, 11, '65.0', 215, 330),
(4, 1, 22, 3, 2, 20, 10, 12, '65.0', 215, 330),
(4, 1, 23, 3, 2, 20, 11, 15, '65.0', 215, 330),
(4, 1, 24, 3, 2, 20, 12, 14, '65.0', 215, 330),
(4, 1, 25, 3, 2, 20, 13, 8, '65.0', 215, 330),
(4, 1, 26, 3, 2, 20, 14, 12, '65.0', 215, 330),
(4, 1, 27, 3, 3, 40, 15, 32, '65.0', 215, 330),
(4, 1, 28, 3, 3, 40, 16, 22, '65.0', 215, 330),
(4, 1, 29, 3, 4, 50, 17, 31, '65.0', 215, 330),
(4, 1, 30, 3, 4, 50, 18, 40, '65.0', 215, 330);

-- --------------------------------------------------------

--
-- Structure de la table `t_section`
--

CREATE TABLE IF NOT EXISTS `t_section` (
  `section_id` int(11) NOT NULL AUTO_INCREMENT,
  `intitule` varchar(50) NOT NULL,
  PRIMARY KEY (`section_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `t_section`
--

INSERT INTO `t_section` (`section_id`, `intitule`) VALUES
(1, 'Scientifique'),
(2, 'Commerciale'),
(3, 'Littéraire');

-- --------------------------------------------------------

--
-- Structure de la table `t_semestre`
--

CREATE TABLE IF NOT EXISTS `t_semestre` (
  `semestre_id` int(11) NOT NULL AUTO_INCREMENT,
  `intitule` varchar(20) NOT NULL,
  `Sigle` varchar(5) NOT NULL,
  PRIMARY KEY (`semestre_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `t_semestre`
--

INSERT INTO `t_semestre` (`semestre_id`, `intitule`, `Sigle`) VALUES
(1, '1è semestre', 'S1'),
(2, '2è semestre', 'S2');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `t_classe`
--
ALTER TABLE `t_classe`
  ADD CONSTRAINT `t_classe_ibfk_1` FOREIGN KEY (`cycle_id`) REFERENCES `t_cycle` (`cycle_id`) ON DELETE NO ACTION,
  ADD CONSTRAINT `t_classe_ibfk_2` FOREIGN KEY (`option_id`) REFERENCES `t_option` (`option_id`) ON DELETE NO ACTION;
